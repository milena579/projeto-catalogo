const card1 = document.querySelector(".primeiro");
const card2 = document.querySelector(".segundo");
const card3 = document.querySelector(".terceiro");

card1.addEventListener("click", function (e) {
  card1.classList.toggle('is-flipped' );
  card1.get
});

card2.addEventListener("click", function (e) {
  card2.classList.toggle('is-flipped' );
});

card3.addEventListener("click", function (e) {
  card3.classList.toggle('is-flipped' );
});